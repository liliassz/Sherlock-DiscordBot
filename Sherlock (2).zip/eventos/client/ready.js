const Discord = require("discord.js");

module.exports = async (client) => {
  console.log("Bot iniciado com sucesso!")

  const status = ["online"]

  const atividades = [
     ["slaslllsals", "WATCHING"],
     ["Jogando", "PLAYING"],
    ];

  setInterval(async () => {
    let i = Math.floor(Math.random() * atividades.length + 1) - 1 
    await client.user.setActivity(atividades[i][0], { type: atividades [i][1], url: atividades [i][2] });
    }, 10000);

  setInterval(async () => {
    let b = Math.floor(Math.random() * status.length + 1) - 1 
    await client.user.setStatus(status[b])
    }, 20000)
};