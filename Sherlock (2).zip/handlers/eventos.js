const { readdirSync } = require("fs");

module.exports = (client) => {
  const load  = dirs => {
    const eventos = readdirSync(`./eventos/${dirs}/`).filter(file => file.endsWith(".js"));
    for(let file of eventos) {
      const funcoes = require(`../eventos/${dirs}/${file}`);
      let eName = file.split('.')[0];
      client.on(eName, funcoes.bind (null, client));
    };
  };
  ["client","guild"].forEach(x => load(x));
};