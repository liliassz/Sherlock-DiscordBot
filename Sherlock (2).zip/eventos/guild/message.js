const Discord = require("discord.js");
const db = require("quick.db");
const saves = require('../../JSONFiles/saves.json');
const config = require('../../JSONFiles/config.json');

module.exports = async (client, message) => {

  const wppBlock = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li|club)|discordapp\.com\/invite|discord\.com\/invite)\/.+[a-z]/gi;
  const logChannel = db.get(`logChannel_${message.guild.id}`);

  if (wppBlock.exec(message.content)) {
		await message.delete({ timeout: 500 });
		await message.channel.send(`${message.author} você é fraco, lhe falta jogar na **Rede Mift** pra enviar links aqui`);
		const linkDiscordEmbed = new Discord.MessageEmbed()
			linkDiscordEmbed.setColor(`${saves.color}`)
			linkDiscordEmbed.setTitle(`Link de Convite`)
			linkDiscordEmbed.addField(`Não sei o motivo, mas deu vontade de apagar a mensagem de:`, `${message.author.tag}`)
			linkDiscordEmbed.addField(`Mas estarei salvando a link que o indivíduo enviou: `, `${message.content}`)
			linkDiscordEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
			linkDiscordEmbed.setTimestamp();
    client.channels.cache.get(logChannel).send(`||<@${saves.ownerBot}>||`, linkDiscordEmbed);
  }

};