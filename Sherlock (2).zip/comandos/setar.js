const Discord = require("discord.js");
const db = require("quick.db");
const saves = require('../../JSONFiles/saves.json');
const config = require('../../JSONFiles/config.json');

module.exports = {
  name: "setar",
  category: "moderacao",
  usage: "setar $var <#canal> | $var <@cargo>",
  description: "Comando para setar canais de Bem Vindo e Saida e cargo inicial",
  aliases: ['setar', 'setarCanal', 'setarCargo'],
  run: (client, message, args) => {
    if (!message.member.hasPermission('ADMINISTRATOR')){
        message.reply("Você é fraco, lhe falta poder de `Administrador` para isso")
    } else if (message.content.includes("Entrada")) {
      let entradaChannel = message.mentions.channels.first()
      if(!entradaChannel) {
        return message.channel.send(`Refaça o comando da seguinte forma: \`\`\`${config.prefix}setar Entrada <#canal>\`\`\``)
      }
      db.set(`entradaChannel_${message.guild.id}`, entradaChannel.id)
      const entradaSetEmbed = new Discord.MessageEmbed()
        entradaSetEmbed.setColor(`${saves.color}`)
        entradaSetEmbed.setDescription(`Canal de Boas Vindas setado com sucesso! Canal: ${entradaChannel}`)
        entradaSetEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        entradaSetEmbed.setTimestamp();

      message.channel.startTyping(); 
      setTimeout(function () {
        message.channel.send(entradaSetEmbed) 
        message.channel.stopTyping();
      }, 1000);

    } else if (message.content.includes("Saida")){
      let saidaChannel = message.mentions.channels.first()
      if(!saidaChannel) {
        return message.channel.send(`Refaça o comando da seguinte forma: \`\`\`${config.prefix}setar Saida <#canal>\`\`\``)
      }
      db.set(`saidaChannel_${message.guild.id}`, saidaChannel.id)
      const saidaSetEmbed = new Discord.MessageEmbed()
        saidaSetEmbed.setColor(`${saves.color}`)
        saidaSetEmbed.setDescription(`Canal de Saída setado com sucesso! Canal: ${saidaChannel}`)
        saidaSetEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        saidaSetEmbed.setTimestamp();

      message.channel.startTyping(); 
      setTimeout(function () {
        message.channel.send(saidaSetEmbed) 
        message.channel.stopTyping();
      }, 1000);

    } else if (message.content.includes("Voice Contador Membro")) {
      let memberCounterVoice = message.mentions.channels.first()
      if(!memberCounterVoice) {
        return message.channel.send(`Refaça o comando da seguinte forma: \`\`\`${config.prefix}setar Voice Contador Membro <#ID DO CANAL>\`\`\``)
      }
      db.set(`memberVoice_${message.guild.id}`, memberCounterVoice.id)
      const memberVoiceEmbed = new Discord.MessageEmbed()
        memberVoiceEmbed.setColor(`${saves.color}`)
        memberVoiceEmbed.setDescription(`Voice de Contaodr de Membros setado com sucesso! Canal: ${memberCounterVoice}`)
        memberVoiceEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        memberVoiceEmbed.setTimestamp();

      message.channel.startTyping(); 
      setTimeout(function () {
        message.channel.send(memberVoiceEmbed) 
        message.channel.stopTyping();
      }, 1000);

    } else if (message.content.includes("Divulgações")){
      let divulgacaoChannel = message.mentions.channels.first()
      if(!divulgacaoChannel) {
        return message.channel.send(`Refaça o comando da seguinte forma: \`\`\`${config.prefix}setar Divulgações <#canal>\`\`\``)
      }
      db.set(`divulgacaoChannel_${message.guild.id}`, divulgacaoChannel.id)
      const divulgacaoSetEmbed = new Discord.MessageEmbed()
        divulgacaoSetEmbed.setColor(`${saves.color}`)
        divulgacaoSetEmbed.setDescription(`Canal de Divulgações setado com sucesso! Canal: ${divulgacaoChannel}`)
        divulgacaoSetEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        divulgacaoSetEmbed.setTimestamp();

      message.channel.startTyping(); 
      setTimeout(function () {
        message.channel.send(divulgacaoSetEmbed) 
        message.channel.stopTyping();
      }, 1000);

    } else if (message.content.includes("DISCORD_Sugestões")){
      let sugestaoChannel = message.mentions.channels.first()
      if(!sugestaoChannel) {
        return message.channel.send(`Refaça o comando da seguinte forma: \`\`\`${config.prefix}setar DISCORD_Sugestões <#canal>\`\`\``)
      }
      db.set(`sugestoesChannel_${message.guild.id}`, sugestaoChannel.id)
      const sugestaoSetEmbed = new Discord.MessageEmbed()
        sugestaoSetEmbed.setColor(`${saves.color}`)
        sugestaoSetEmbed.setDescription(`Canal de Divulgações setado com sucesso! Canal: ${sugestaoChannel}`)
        sugestaoSetEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        sugestaoSetEmbed.setTimestamp();

      message.channel.startTyping(); 
      setTimeout(function () {
        message.channel.send(sugestaoSetEmbed) 
        message.channel.stopTyping();
      }, 1000);

    } else if (message.content.includes("BOT_Sugestões")){
      let sugestaoBOTChannel = message.mentions.channels.first()
      if(!sugestaoBOTChannel) {
        return message.channel.send(`Refaça o comando da seguinte forma: \`\`\`${config.prefix}setar BOT_Sugestões <#canal>\`\`\``)
      }
      db.set(`sugestoesBOTChannel_${message.guild.id}`, sugestaoBOTChannel.id)
      const sugestaoBOTSetEmbed = new Discord.MessageEmbed()
        sugestaoBOTSetEmbed.setColor(`${saves.color}`)
        sugestaoBOTSetEmbed.setDescription(`Canal de Sugestões do BOT setado com sucesso! Canal: ${sugestaoBOTChannel}`)
        sugestaoBOTSetEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        sugestaoBOTSetEmbed.setTimestamp();

      message.channel.startTyping(); 
      setTimeout(function () {
        message.channel.send(sugestaoBOTSetEmbed) 
        message.channel.stopTyping();
      }, 1000);

    } else if (message.content.includes("Log")) {
      let logChannel = message.mentions.channels.first()
      if(!logChannel) {
        return message.channel.send(`Refaça o comando da seguinte forma: \`\`\`${config.prefix}setar Log <#canal>\`\`\``)
      }
      db.set(`logChannel_${message.guild.id}`, logChannel.id)
      const logSetEmbed = new Discord.MessageEmbed()
        logSetEmbed.setColor(`${saves.color}`)
        logSetEmbed.setDescription(`Canal de Log setado com sucesso! Canal: ${logChannel}`)
        logSetEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        logSetEmbed.setTimestamp();
      
      message.channel.startTyping(); 
      setTimeout(function () {
        message.channel.send(logSetEmbed) 
        message.channel.stopTyping();
      }, 1000);

    } else if (message.content.includes("Cargo")) {
      let cargoInicial = message.mentions.roles.first()
      if(!cargoInicial) {
        return message.channel.send(`Refaça o comando da seguinte forma: \`\`\`${config.prefix}setar Cargo <@cargo>\`\`\``)
      }
      db.set(`cargo_${message.guild.id}`, cargoInicial.id)
      const cargoSetEmbed = new Discord.MessageEmbed()
        cargoSetEmbed.setColor(`${saves.color}`)
        cargoSetEmbed.setDescription(`Cargo setado com sucesso! Cargo Inicial: ${cargoInicial}`)
        cargoSetEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        cargoSetEmbed.setTimestamp();
      
      message.channel.startTyping(); 
      setTimeout(function () {
        message.channel.send(cargoSetEmbed) 
        message.channel.stopTyping();
      }, 1000);

    } else if (message.content.includes("Punições")) {
      let punicaoChannel = message.mentions.channels.first()
      if (!punicaoChannel) {
        message.channel.startTyping();
        setTimeout(function () {
          message.channel.stopTyping();
          return message.channel.send(`\`\`\`${config.prefix}setar Punições <#canal>\`\`\``)
        }, 1000);
      }
      db.set(`punicoesChannel_${message.guild.id}`, punicaoChannel.id)
      const punicaoSetEmbed = new Discord.MessageEmbed()
        punicaoSetEmbed.setColor(`${saves.color}`)
        punicaoSetEmbed.setDescription(`Canal de Punições setado com sucesso!`)
        punicaoSetEmbed.setFooter(`${message.guild.name}`, client.user.displayAvatarURL())
        punicaoSetEmbed.setTimestamp();

      message.channel.startTyping();
      setTimeout(function () {
        message.channel.stopTyping();
        message.channel.send(punicaoSetEmbed)
      }, 1000);
    } else {      

      const setsCargos_CanaisEmbed = new Discord.MessageEmbed()
        setsCargos_CanaisEmbed.setColor(`${saves.color}`)
        setsCargos_CanaisEmbed.setTitle(`Canais e Cargos Setados`)
        setsCargos_CanaisEmbed.addField(`${saves.emojiWelcome} Canal de Entrada`, `${db.fetch(`entradaChannel_${message.guild.id}`) !== null ? `**<#${db.fetch(`entradaChannel_${message.guild.id}`)}>**` : `\`\`\`${config.prefix}setar Entrada <#canal>\`\`\``} `)
        setsCargos_CanaisEmbed.addField(`${saves.emojiGoodBye} Canal de Saída`, `${db.fetch(`saidaChannel_${message.guild.id}`) !== null ? `<#${db.fetch(`saidaChannel_${message.guild.id}`)}>` : `\`\`\`${config.prefix}setar Saida <#canal>\`\`\``} `)
        setsCargos_CanaisEmbed.addField(`${saves.emojiVoiceCounter} Voice ServerStats Membros`, `${db.fetch(`memberVoice_${message.guild.id}`) !== null ? `<#${db.fetch(`memberVoice_${message.guild.id}`)}>` : `\`\`\`${config.prefix}setar Voice Contador Membro <#ID DO CANAL>\`\`\``} `)
        setsCargos_CanaisEmbed.addField(`${saves.emojiDivulgacao} Canal de Divulgação`, `${db.fetch(`divulgacaoChannel_${message.guild.id}`) !== null ? `<#${db.fetch(`divulgacaoChannel_${message.guild.id}`)}>` : `\`\`\`${config.prefix}setar Divulgações <#canal>\`\`\``} `)
        setsCargos_CanaisEmbed.addField(`${saves.emojiSugestao} Canal de Sugestões`, `${db.fetch(`sugestoesChannel_${message.guild.id}`) !== null ? `<#${db.fetch(`sugestoesChannel_${message.guild.id}`)}>` : `\`\`\`${config.prefix}setar DISCORD_Sugestões <#canal>\`\`\``} `)
        setsCargos_CanaisEmbed.addField(`${saves.emojiSugestaoBOT} Canal de Sugestões do BOT`, `${db.fetch(`sugestoesBOTChannel_${message.guild.id}`) !== null ? `<#${db.fetch(`sugestoesBOTChannel_${message.guild.id}`)}>` : `\`\`\`${config.prefix}setar BOT_Sugestões <#canal>\`\`\``} `)
        setsCargos_CanaisEmbed.addField(`${saves.emojiLog} Canal de Log`, `${db.fetch(`logChannel_${message.guild.id}`) !== null ? `<#${db.fetch(`logChannel_${message.guild.id}`)}>` : `\`\`\`${config.prefix}setar Log <#canal>\`\`\``} `)
        setsCargos_CanaisEmbed.addField(`Canal de Punições`, `${db.fetch(`punicoesChannel_${message.guild.id}`) !== null ? `<#${db.fetch(`punicoesChannel_${message.guild.id}`)}>` : `\`\`\`${config.prefix}setar Punições <#canal>\`\`\``} `)
        setsCargos_CanaisEmbed.addField(`${saves.emojiCargoIncial} Cargo Inicial`, `${db.fetch(`cargo_${message.guild.id}`) !== null ? `<#${db.fetch(`cargo_${message.guild.id}`)}>` : `\`\`\`${config.prefix}setar Cargo <@cargo>\`\`\``} `)
        setsCargos_CanaisEmbed.setFooter(`© Todos os direitos reservados`, client.user.displayAvatarURL())
        setsCargos_CanaisEmbed.setTimestamp();

      message.channel.startTyping();
      setTimeout(function () {
        message.channel.send(`${message.author}`, setsCargos_CanaisEmbed);
        message.channel.stopTyping();
      }, 2000);

    }
  }
}